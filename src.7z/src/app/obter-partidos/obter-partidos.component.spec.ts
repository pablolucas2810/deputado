import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ObterPartidosComponent } from './obter-partidos.component';

describe('ObterPartidosComponent', () => {
  let component: ObterPartidosComponent;
  let fixture: ComponentFixture<ObterPartidosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ObterPartidosComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ObterPartidosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
