import { Component, OnInit } from '@angular/core';
import { Partido } from '../model/partido';
import { DeputadoService } from '../model/deputado.service';

@Component({
  selector: 'app-obter-partidos',
  templateUrl: './obter-partidos.component.html',
  styleUrls: ['./obter-partidos.component.css']
})
export class ObterPartidosComponent implements OnInit {
  partidos: Partido[];

  constructor(private part: DeputadoService) {
    this.partidos = [];
   }

  ngOnInit() {
    this.part.obterPartidos().subscribe((res) => {
      this.partidos = res.dados});
  }

}
