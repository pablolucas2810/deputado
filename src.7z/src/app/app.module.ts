import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DeputadoService } from './model/deputado.service';
import { ObterDeputadosComponent } from './obter-deputados/obter-deputados.component';
import { ObterPartidosComponent } from './obter-partidos/obter-partidos.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    ObterDeputadosComponent,
    ObterPartidosComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [DeputadoService],
  bootstrap: [AppComponent]
})
export class AppModule { }
