import { Component, OnInit } from '@angular/core';
import { Deputado } from '../model/deputado';
import { DeputadoService } from '../model/deputado.service';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-obter-deputados',
  templateUrl: './obter-deputados.component.html',
  styleUrls: ['./obter-deputados.component.css']
})
export class ObterDeputadosComponent implements OnInit {
  deputados: Deputado[];
  search = new FormControl('');

  constructor(private dep: DeputadoService) {
    this.deputados = [];
  }

  ngOnInit() {
    this.dep.obterDeputados(this.search.value).subscribe((res) => {
      this.deputados = res.dados;});
  }

  onChange() {
    this.dep.obterDeputados(this.search.value).subscribe((res) => {
      this.deputados = res.dados;});
  }
}
