import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ObterDeputadosComponent } from './obter-deputados.component';

describe('ObterDeputadosComponent', () => {
  let component: ObterDeputadosComponent;
  let fixture: ComponentFixture<ObterDeputadosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ObterDeputadosComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ObterDeputadosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
