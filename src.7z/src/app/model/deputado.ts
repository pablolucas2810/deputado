export class Deputado {
    email: string = "";
    id: number = 0;
    idLegislatura: number = 0;
    nome: string = "";
    siglaPartido: string = "";
    siglaUf: string = "";
    uri: string = "";
    uriPartido: string = "";
    urlFoto: string = "";
}