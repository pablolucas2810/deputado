export class Partido {
    nome: string = "";
    sigla: string = "";
}