import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DeputadoService {
  private URL: string;

  constructor(private http: HttpClient) {
    this.URL = "https://dadosabertos.camara.leg.br/api/v2/"
   }

   obterDeputados(nome: string | null): Observable<any> {
    if (nome)
      return this.http.get(`${this.URL}deputados?nome=${nome}&ordem=ASC&ordenarPor=nome`);
    return this.http.get(`${this.URL}deputados`);
    //return null;
  }

  obterPartidos(): Observable<any> {
    return this.http.get<any>(`${this.URL}partidos?ordem=ASC&ordenarPor=sigla`)
  }

}
